# Sistema de Priorização de Projetos por Necessidade de Atenção (AHP + SAW)

## Português
Ordena 4.000 projetos (Kaggle, `project_risk_raw_dataset.csv`) por **necessidade de atenção relacionada a risco**.
Pontuação maior = maior prioridade de atenção. Não significa projeto "melhor" ou mais rentável; é apoio à decisão.

**Critérios** (proposta inicial, sujeita à confirmação no dicionário da base):
| Cód. | Campo | Sentido | Normalização |
|---|---|---|---|
| C1 | Complexity_Score | maior = mais risco | x/max |
| C2 | Schedule_Pressure | maior = mais risco | x/max |
| C3 | Historical_Risk_Incidents | maior = mais risco | x/max |
| C4 | Resource_Availability | menor = mais risco | min/x |
| C5 | Vendor_Reliability_Score | menor = mais risco | min/x |

Pontuação_j = Σ peso_i × r_ij. Pesos via AHP (autovetor principal, CI/CR com RI de Saaty).
`Risk_Level` e `Priority_Level` **não** entram no cálculo.

**Instalação e execução**
```
pip install -r requirements.txt
python src/main.py
```
Saídas em `resultados/`: `ranking_saw.csv`, `resultados.xlsx`, `priorizacao.db` (SQLite), gráficos `.png`, `execucao.log`.
Para mudar pesos, edite `documentacao/julgamentos_ahp.json` e rode de novo (se CR > 0,10 o programa para).

**Dados:** a base não deve ser redistribuída sem verificar a licença no Kaggle. Baixe na fonte original, cite a publicação e coloque o CSV em `dados/` com o nome `project_risk_raw_dataset.ORIGINAL.csv`.

## English
Ranks projects by *need for attention* (risk) using AHP (criteria weights, CR ≤ 0.10) + SAW (weighted sum with
x/max for risk-increasing criteria and min/x for risk-decreasing ones). Run `pip install -r requirements.txt && python src/main.py`.
Higher score = higher attention priority; it is decision support, not a replacement for managers.
Check the dataset license on Kaggle before redistributing; cite the original source.
