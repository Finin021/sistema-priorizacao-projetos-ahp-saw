# Fonte dos dados — Project Management Risk Raw

Este documento descreve a origem, a licença e as características da base de dados utilizada neste projeto, para que qualquer pessoa possa conferir de onde vêm os dados e reproduzir o trabalho.

## 1. Identificação da base

| Item | Informação |
|---|---|
| Título | Project management Risk Raw |
| Plataforma | Kaggle |
| Autor | Tarek Adam (usuário `ka66ledata`) |
| Link | https://www.kaggle.com/datasets/ka66ledata/project-management-risk-raw |
| Descrição na página | "Project Risk Prediction: A Comprehensive Dataset for Machine Learning" |
| Descrição do arquivo | "Simulated project management data tailored for machine learning risk analysis." |
| Licença | Community Data License Agreement – Permissive, Version 1.0 (CDLA-Permissive-1.0): https://cdla.dev/permissive-1-0/ |
| Ano | 2025 (a página indica "Updated a year ago") |
| Frequência de atualização | "Never" (indicada na página) |
| Arquivo utilizado | `project_risk_raw_dataset.csv` (1,22 MB) |
| Acessado em | 11/11/2026 |

## 2. Natureza dos dados

A própria página da base informa que os dados são **simulados**. O autor descreve o conjunto como uma coleção de "50 simulated project management related data points" criada para praticar análise exploratória e aprendizado de máquina e afirma que, com a ajuda de inteligência artificial, procurou oferecer características relevantes e interdependências entre os dados.

Por isso, neste trabalho os resultados **não representam projetos reais**. Eles servem para demonstrar e testar o método (AHP + SAW) e o protótipo desenvolvido. Também não considero a coluna `Risk_Level` como uma verdade validada, já que não sei como ela foi gerada.

## 3. Estrutura do arquivo analisado

Na minha análise do arquivo, encontrei:

- 4.000 registros e 51 colunas;
- `Project_ID` único em todas as linhas e nenhuma linha duplicada;
- nenhum valor ausente nos cinco campos usados no modelo (há valores ausentes em outras colunas, que não participam do cálculo).

Estatísticas dos campos usados:

| Campo | Mínimo | Média | Máximo | Quantidade de zeros |
|---|---|---|---|---|
| Complexity_Score | 1,62 | 6,19 | 10,00 | 0 |
| Schedule_Pressure | 0,00 | 0,053 | 0,58 | 2.415 |
| Historical_Risk_Incidents | 0 | 1,51 | 8 | 857 |
| Resource_Availability | 0,30 | 0,65 | 1,00 | 0 |
| Vendor_Reliability_Score | 0,09 | 0,71 | 1,00 | 0 |

As colunas `Risk_Level` e `Priority_Level` (ambas com os valores Low, Medium, High e Critical) existem na base, mas **não entram no cálculo** do ranking.

## 4. Campos utilizados e interpretação adotada

A página do Kaggle não detalha, nos trechos que consultei, o significado e a escala dos cinco campos abaixo. A interpretação apresentada é **uma hipótese minha** para a construção do modelo, e não uma definição oficial da base. A escala indicada é a que observei nos dados.

| Campo | Interpretação adotada | Escala observada |
|---|---|---|
| Complexity_Score | Pontuação de complexidade do projeto; quanto maior, maior a necessidade de atenção | 1,62 a 10 |
| Schedule_Pressure | Pressão sobre o cronograma; quanto maior, maior a necessidade de atenção | 0 a 0,58 |
| Historical_Risk_Incidents | Quantidade de incidentes de risco anteriores; quanto maior, maior a necessidade de atenção | 0 a 8 |
| Resource_Availability | Disponibilidade de recursos; quanto menor, maior a necessidade de atenção | 0,30 a 1,00 |
| Vendor_Reliability_Score | Confiabilidade dos fornecedores; quanto menor, maior a necessidade de atenção | 0,09 a 1,00 |

Das descrições oficiais que consegui ler na página, constam: `Project_ID` ("identificador único de cada projeto"), `Team_Size` ("número de pessoas alocadas ao projeto"), `Estimated_Timeline_Months` ("duração projetada do projeto em meses") e `Complexity_Score` (uma pontuação numérica que indica a dificuldade do projeto; o texto aparecia cortado).

**Limitação:** como a documentação consultada não detalha a escala e o cálculo desses campos, as interpretações acima precisam ser vistas como hipóteses do autor.

## 5. Licença e uso dos dados

Os dados são distribuídos sob a licença **CDLA-Permissive-1.0**, cujo texto completo li. Em resumo:

- **Uso:** é permitido usar, estudar e analisar os dados, inclusive por meio computacional (Seção 2.1).
- **Redistribuição:** é permitida, desde que quem receber a cópia também receba o texto, o nome ou um link da licença e que o crédito ao autor seja mantido (Seção 3.1).
- **Dados modificados:** arquivos alterados em relação ao original devem trazer aviso de que foram modificados (Seção 3.1b). Neste projeto, o arquivo `dados_preparados.csv` é derivado do original, pois contém apenas o `Project_ID` e os cinco campos do modelo.
- **Resultados:** a licença não impõe obrigações nem restrições ao uso e à publicação dos resultados (Seção 3.4), como o ranking, os pesos e os gráficos.
- **Garantias:** os dados são fornecidos "como estão", sem garantias (Seção 6).

## 6. Como obter os dados

1. Acesse o link da seção 1 e clique em **Download**.
2. Extraia o arquivo `project_risk_raw_dataset.csv` para a pasta `dados/` do projeto.
3. Não edite esse arquivo. Todos os tratamentos são feitos pelo programa, que gera o arquivo derivado `dados_preparados.csv`.

## 7. Referência

```
ADAM, Tarek. Project management Risk Raw. [S. l.]: Kaggle, 2025. Conjunto de dados.
Disponível em: https://www.kaggle.com/datasets/ka66ledata/project-management-risk-raw.
Acesso em: 11 nov. 2026.
```
