# Guia passo a passo (do CSV ao TCC)

## 1. O que foi encontrado nos dados (já verificado)
- 4.000 linhas, 51 colunas, `Project_ID` único, 0 duplicadas, 0 nulos nos 5 critérios (a base tem nulos em OUTRAS colunas; não afetam o modelo).
- Zeros: Schedule_Pressure 2.415 (60%), Historical_Risk_Incidents 857; Resource_Availability e Vendor_Reliability **sem zeros** (mín. 0,30 e 0,09) → `min/x` é matematicamente seguro, sem somar "número pequeno".
- Correlações entre os 5 critérios: todas |r| ≤ 0,12 → sem redundância.
- `Risk_Level` quase só varia com Complexity_Score (média 5,25 em Low → 7,59 em Critical); os outros 4 campos quase não diferem entre classes. Isso indica base **sintética** e que Risk_Level provavelmente foi gerado com a complexidade. Por isso a comparação com Risk_Level é só exploratória (Spearman 0,33).

## 2. Resultados do modelo (execução real)
Pesos AHP: C1 37,6% · C2 21,5% · C3 21,5% · C4 12,1% · C5 7,4%. λmax=5,0331, CI=0,0083, **CR=0,0074** (≤ 0,10).
Sensibilidade (±20% nos pesos, 200 simulações): Spearman médio 0,997; Top-100 retido em média 90%.
**Achado importante para discutir no TCC:** peso nominal ≠ influência efetiva. C1 tem 37,6% de peso mas 47,7% da influência no ranking; C5 tem 7,4% de peso e só ~2% de influência, porque `min/x` com mínimo 0,09 (outlier) comprime quase todos os valores perto de 0,1–0,2. Alternativa a testar na validação: normalização min–max (x−min)/(max−min) e comparar rankings.

## 3. Pendências que só VOCÊ pode fechar (o guia exige)
1. Abrir a página da base no Kaggle (o acesso automático falhou) e anotar: autor, link, **licença**, dicionário de dados. Confirmar escala de cada campo (ex.: Resource_Availability 0–1? Schedule_Pressure é razão?).
2. Decidir quem julga o AHP (autor como cenário experimental ou um gestor). Ajustar `julgamentos_ahp.json` e justificar.
3. Citar a publicação original da base nas referências.

## 4. O que alterar no AVA2 (metodologia)
- Trocar "projetos fictícios" por: base pública do Kaggle com 4.000 registros / 51 colunas, usando 5 campos.
- Trocar os 4 critérios (Impacto, Prazo, Custo...) pelos 5 acima; Quadro 1 com campo, sentido e normalização; remover o Quadro 2 (escala de impacto) ou adaptá-lo.
- Matriz agora é 5×5 (10 comparações, RI=1,12); pesos pelo autovetor (a média de colunas do AVA2 fica como conferência — diferença < 0,002).
- Reescrever o objetivo: ranking por **necessidade de atenção ao risco**, não "prioridade de negócio".
- Acrescentar a etapa SAW com fórmulas x/max e min/x, e a justificativa de não haver divisão por zero.
- Resultados: tabelas de estatística descritiva, matriz, pesos, CI/CR, top 10, testes, sensibilidade, cenários e a discussão peso×influência.
- Limitações: base sintética, julgamentos do autor, Risk_Level de origem desconhecida.

## 5. Ordem de execução
Confirmar base → rodar `python src/main.py` → conferir log → ajustar julgamentos se quiser → publicar no GitHub (sem o CSV se a licença não permitir; `.gitignore` já sugerido) → atualizar o TCC com os números do `execucao.log`.
