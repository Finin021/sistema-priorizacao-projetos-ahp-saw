"""AHP: matriz recíproca 5x5, pesos (autovetor principal), CI e CR."""
import json
import numpy as np
from config import CRITERIOS, RI, CR_LIMITE, JULGAMENTOS


def montar_matriz(caminho=JULGAMENTOS):
    j = json.load(open(caminho, encoding="utf-8"))
    cods = j["ordem_criterios"]
    idx = {c: i for i, c in enumerate(cods)}
    n = len(cods)
    A = np.ones((n, n))
    for a, b, v, _ in j["comparacoes"]:
        if not (1 / 9 <= v <= 9):
            raise ValueError(f"Valor fora da escala de Saaty: {a}x{b}={v}")
        A[idx[a], idx[b]] = v
        A[idx[b], idx[a]] = 1 / v
    return A, cods


def pesos_autovetor(A, iteracoes=1000, tol=1e-12):
    """Método da potência (autovetor principal) -> pesos normalizados e lambda_max."""
    n = A.shape[0]
    w = np.ones(n) / n
    for _ in range(iteracoes):
        w_novo = A @ w
        w_novo /= w_novo.sum()
        if np.abs(w_novo - w).max() < tol:
            w = w_novo
            break
        w = w_novo
    lam = float(np.mean((A @ w) / w))
    return w, lam


def pesos_media_colunas(A):
    """Método aproximado (normalizar colunas e tirar média das linhas) — usado no AVA2; serve de conferência."""
    return (A / A.sum(axis=0)).mean(axis=1)


def consistencia(A, lam):
    n = A.shape[0]
    ci = (lam - n) / (n - 1)
    cr = ci / RI[n] if RI[n] > 0 else 0.0
    return ci, cr


def calcular(caminho=JULGAMENTOS):
    A, cods = montar_matriz(caminho)
    w, lam = pesos_autovetor(A)
    ci, cr = consistencia(A, lam)
    return {"matriz": A, "codigos": cods, "pesos": w, "pesos_media_colunas": pesos_media_colunas(A),
            "lambda_max": lam, "CI": ci, "CR": cr, "consistente": cr <= CR_LIMITE}
