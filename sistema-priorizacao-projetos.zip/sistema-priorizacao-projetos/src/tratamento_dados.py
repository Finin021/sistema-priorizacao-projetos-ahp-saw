"""Valida e prepara os 5 campos. Toda decisão é registrada em `log`."""
import pandas as pd
import numpy as np
from config import COL_ID, CAMPOS, CRITERIOS


def preparar(df: pd.DataFrame):
    log = []
    n0 = len(df)
    base = df[[COL_ID] + CAMPOS].copy()

    # 1) tipos numéricos
    for c in CAMPOS:
        base[c] = pd.to_numeric(base[c], errors="coerce")
    # 2) ausentes -> exclusão registrada (nunca imputação silenciosa)
    ausentes = base[CAMPOS].isna().any(axis=1)
    if ausentes.any():
        log.append(f"Excluídas {int(ausentes.sum())} linhas com valor ausente nos critérios.")
        base = base[~ausentes]
    # 3) negativos
    neg = (base[CAMPOS] < 0).any(axis=1)
    if neg.any():
        log.append(f"Excluídas {int(neg.sum())} linhas com valores negativos.")
        base = base[~neg]
    # 4) duplicidade de ID
    dup = base[COL_ID].duplicated()
    if dup.any():
        log.append(f"Excluídas {int(dup.sum())} linhas com Project_ID duplicado.")
        base = base[~dup]
    # 5) zeros em critérios de custo (min/x indefinido)
    for c in CRITERIOS:
        if c["sentido"] == "min" and (base[c["campo"]] <= 0).any():
            raise ValueError(f"{c['campo']} contém zero/negativo: defina transformação antes de usar min/x.")
    # 6) máximo zero em critério de benefício
    for c in CRITERIOS:
        if c["sentido"] == "max" and base[c["campo"]].max() <= 0:
            raise ValueError(f"{c['campo']} tem máximo <= 0: x/max indefinido.")

    zeros = {c: int((base[c] == 0).sum()) for c in CAMPOS}
    log.append(f"Linhas: {n0} -> {len(base)} (nenhuma exclusão)" if len(base) == n0
               else f"Linhas: {n0} -> {len(base)}")
    log.append(f"Zeros por campo (informativo): {zeros}")
    return base.reset_index(drop=True), log


def estatisticas(base: pd.DataFrame) -> pd.DataFrame:
    return base[CAMPOS].describe().T
