"""Orquestrador. Uso:  python src/main.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from config import *
import carregar_dados, tratamento_dados, ahp, saw, database, validacao


def main():
    RESULTADOS.mkdir(exist_ok=True)
    df = carregar_dados.carregar()
    est = carregar_dados.resumo_estrutura(df)
    print("== ESTRUTURA ==", est)
    base, log = tratamento_dados.preparar(df)
    base.to_csv(CSV_PREPARADO, index=False)
    print("== TRATAMENTO =="); [print(" -", l) for l in log]
    desc = tratamento_dados.estatisticas(base); print(desc.round(3).to_string())

    print("\n== CRITÉRIOS ==")
    for c in CRITERIOS:
        print(f" {c['codigo']} {c['campo']:<27} {'maior=mais risco (x/max)' if c['sentido']=='max' else 'menor=mais risco (min/x)'}")

    a = ahp.calcular()
    print("\n== AHP ==")
    print(pd.DataFrame(a["matriz"], index=a["codigos"], columns=a["codigos"]).round(3).to_string())
    for cod, p, p2 in zip(a["codigos"], a["pesos"], a["pesos_media_colunas"]):
        print(f" {cod}: {p:.4f} ({100*p:.2f}%)   [média de colunas: {p2:.4f}]")
    print(f" lambda_max={a['lambda_max']:.4f}  CI={a['CI']:.4f}  CR={a['CR']:.4f}  -> {'CONSISTENTE' if a['consistente'] else 'REVISAR JULGAMENTOS'}")
    if not a["consistente"]:
        sys.exit("CR > 0,10: revise documentacao/julgamentos_ahp.json")

    res = saw.pontuar(base, a["pesos"])
    print("\n== RANKING (top 10) ==")
    print(res[["Ranking", COL_ID, "Pontuacao_SAW"]].head(10).to_string(index=False))

    t = validacao.testes(base, a, res)
    print("\n== TESTES =="); [print(f" [{'OK' if v else 'FALHOU'}] {k}") for k, v in t.items()]
    sens = validacao.sensibilidade(base, a["pesos"]); print("\n== SENSIBILIDADE (±20% nos pesos) ==", sens)
    cen = validacao.cenarios(base, a["pesos"]); print("\n== CENÁRIOS ==\n", cen.round(3).to_string(index=False))
    inf = validacao.influencia_efetiva(res, a["pesos"]); print("\n== INFLUÊNCIA EFETIVA ==\n", inf.round(4).to_string(index=False))
    media, rho = validacao.comparacao_exploratoria(df, res)
    print("\n== COMPARAÇÃO EXPLORATÓRIA COM Risk_Level (não é validação definitiva) ==\n", media.round(4).to_string(), f"\n Spearman={rho:.3f}")

    con = database.conectar(BANCO)
    eid = database.salvar_execucao(con, base, a, res, obs="pesos AHP v1")
    print(f"\n== SQLITE == execução id={eid}; top3:", database.top(con, eid, 3))

    # exportações
    res.to_csv(RESULTADOS / "ranking_saw.csv", index=False, encoding="utf-8-sig")
    with pd.ExcelWriter(RESULTADOS / "resultados.xlsx") as xw:
        res.to_excel(xw, sheet_name="Ranking", index=False)
        pd.DataFrame(a["matriz"], index=a["codigos"], columns=a["codigos"]).to_excel(xw, sheet_name="Matriz_AHP")
        pd.DataFrame({"Criterio": a["codigos"], "Peso": a["pesos"]}).to_excel(xw, sheet_name="Pesos", index=False)
        desc.to_excel(xw, sheet_name="Estatisticas"); cen.to_excel(xw, sheet_name="Cenarios", index=False); inf.to_excel(xw, sheet_name="Influencia", index=False)
    graficos(res, a, inf)
    print("\nArquivos em resultados/: ranking_saw.csv, resultados.xlsx, priorizacao.db, *.png")


def graficos(res, a, inf):
    cod = a["codigos"]
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].bar(cod, a["pesos"], color="#2a6f97"); ax[0].set_title("Pesos AHP (nominais)")
    ax[1].bar(inf["Critério"], inf["Influência efetiva (%)"], color="#c26a2e"); ax[1].set_title("Influência efetiva no ranking (%)")
    plt.tight_layout(); plt.savefig(RESULTADOS / "pesos_vs_influencia.png", dpi=150); plt.close()
    top = res.head(20).iloc[::-1]
    fig, ax = plt.subplots(figsize=(9, 6)); left = np.zeros(len(top))
    cores = ["#1f4e79", "#2a6f97", "#61a5c2", "#c26a2e", "#e0a96d"]
    for c, cor, k in zip(CAMPOS, cores, cod):
        ax.barh(top[COL_ID], top["contrib_" + c], left=left, color=cor, label=f"{k} {c}"); left += top["contrib_" + c].values
    ax.set_title("Top 20: contribuição de cada critério à pontuação SAW"); ax.legend(fontsize=7, loc="lower right")
    plt.tight_layout(); plt.savefig(RESULTADOS / "top20_contribuicoes.png", dpi=150); plt.close()
    plt.figure(figsize=(7, 4)); plt.hist(res["Pontuacao_SAW"], bins=40, color="#2a6f97")
    plt.title("Distribuição da pontuação SAW"); plt.xlabel("Pontuação"); plt.tight_layout()
    plt.savefig(RESULTADOS / "distribuicao_pontuacao.png", dpi=150); plt.close()


if __name__ == "__main__":
    main()
