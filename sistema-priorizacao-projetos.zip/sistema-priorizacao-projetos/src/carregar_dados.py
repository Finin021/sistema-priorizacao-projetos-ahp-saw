"""Abre o CSV e confere a estrutura básica."""
import pandas as pd
from config import CSV_ORIGINAL, COL_ID, CAMPOS


def carregar(caminho=CSV_ORIGINAL) -> pd.DataFrame:
    df = pd.read_csv(caminho)
    faltando = [c for c in [COL_ID] + CAMPOS if c not in df.columns]
    if faltando:
        raise ValueError(f"Colunas ausentes no CSV: {faltando}")
    return df


def resumo_estrutura(df: pd.DataFrame) -> dict:
    return {"linhas": len(df), "colunas": df.shape[1],
            "id_unico": bool(df[COL_ID].is_unique),
            "duplicadas": int(df.duplicated().sum()),
            "nulos_nos_criterios": int(df[CAMPOS].isna().sum().sum())}
