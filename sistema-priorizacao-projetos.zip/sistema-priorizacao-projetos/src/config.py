"""Configuração central: caminhos, critérios e sentidos de preferência."""
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
CSV_ORIGINAL = RAIZ / "dados" / "project_risk_raw_dataset.csv"
CSV_PREPARADO = RAIZ / "dados" / "dados_preparados.csv"
BANCO = RAIZ / "resultados" / "priorizacao.db"
JULGAMENTOS = RAIZ / "documentacao" / "julgamentos_ahp.json"
RESULTADOS = RAIZ / "resultados"

COL_ID = "Project_ID"

# sentido: "max" -> valor MAIOR = maior risco  (normalização x/max)
#          "min" -> valor MENOR = maior risco  (normalização min/x)
CRITERIOS = [
    {"codigo": "C1", "campo": "Complexity_Score",          "nome": "Complexidade do projeto",        "sentido": "max"},
    {"codigo": "C2", "campo": "Schedule_Pressure",         "nome": "Pressão sobre o cronograma",     "sentido": "max"},
    {"codigo": "C3", "campo": "Historical_Risk_Incidents", "nome": "Incidentes históricos de risco", "sentido": "max"},
    {"codigo": "C4", "campo": "Resource_Availability",     "nome": "Disponibilidade de recursos",    "sentido": "min"},
    {"codigo": "C5", "campo": "Vendor_Reliability_Score",  "nome": "Confiabilidade dos fornecedores","sentido": "min"},
]
CAMPOS = [c["campo"] for c in CRITERIOS]

# Valores de referência de consistência (Saaty): RI por ordem n
RI = {1: 0.0, 2: 0.0, 3: 0.58, 4: 0.90, 5: 1.12, 6: 1.24, 7: 1.32, 8: 1.41, 9: 1.45, 10: 1.49}
CR_LIMITE = 0.10
