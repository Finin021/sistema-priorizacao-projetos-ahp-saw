"""Testes (matemático, direção, pesos, ranking), sensibilidade e comparação exploratória."""
import numpy as np
import pandas as pd
from config import CRITERIOS, CAMPOS, COL_ID
import saw
import ahp as ahpmod


def testes(base, A_res, resultado):
    r = {}
    # T1 matemático: confere 3 projetos manualmente
    w = A_res["pesos"]
    ok = True
    for i in [0, len(base) // 2, len(base) - 1]:
        s = 0
        for k, c in enumerate(CRITERIOS):
            x = base.loc[i, c["campo"]]
            col = base[c["campo"]]
            n = x / col.max() if c["sentido"] == "max" else col.min() / x
            s += w[k] * n
        s_prog = resultado.loc[resultado[COL_ID] == base.loc[i, COL_ID], "Pontuacao_SAW"].iloc[0]
        ok &= abs(s - s_prog) < 1e-12
    r["T1 cálculo manual confere com o programa"] = bool(ok)
    # T2 direção: aumentar benefício eleva; reduzir custo eleva (demais fixos)
    t2 = True
    for c in CRITERIOS:
        b = base.copy()
        i = 0
        antes = saw.pontuar(b, w).set_index(COL_ID).loc[b.loc[i, COL_ID], "Pontuacao_SAW"]
        # piora o critério numa direção de risco sem alterar max/min globais
        col = b[c["campo"]]
        if c["sentido"] == "max":
            b.loc[i, c["campo"]] = col.max() if col.iloc[i] < col.max() else col.iloc[i]
        else:
            b.loc[i, c["campo"]] = col.min() if col.iloc[i] > col.min() else col.iloc[i]
        depois = saw.pontuar(b, w).set_index(COL_ID).loc[b.loc[i, COL_ID], "Pontuacao_SAW"]
        t2 &= depois >= antes - 1e-12
    r["T2 direção de preferência correta"] = bool(t2)
    r["T3 CR <= 0,10"] = bool(A_res["CR"] <= 0.10)
    r["T4 pesos positivos e somam 1"] = bool((w > 0).all() and abs(w.sum() - 1) < 1e-9)
    r["T5 ranking em ordem decrescente"] = bool(resultado["Pontuacao_SAW"].is_monotonic_decreasing)
    r["T6 pontuações em (0,1]"] = bool(resultado["Pontuacao_SAW"].between(0, 1).all())
    r["T7 AHP: autovetor ≈ média de colunas (tol. 0,02)"] = bool(np.abs(w - A_res["pesos_media_colunas"]).max() < 0.02)
    return r


def _rho(a, b):
    """Spearman sem scipy: correlação de Pearson dos postos."""
    return float(pd.Series(a).rank().corr(pd.Series(b).rank()))


def sensibilidade(base, pesos, n_sim=200, variacao=0.20, semente=42, k=100):
    """Perturba cada peso em ±variacao (multiplicativo), renormaliza e compara com o ranking-base."""
    rng = np.random.default_rng(semente)
    ref = saw.pontuar(base, pesos).set_index(COL_ID)["Ranking"]
    topo_ref = set(ref[ref <= k].index)
    rhos, ints = [], []
    for _ in range(n_sim):
        p = np.asarray(pesos) * rng.uniform(1 - variacao, 1 + variacao, len(pesos))
        p /= p.sum()
        rk = saw.pontuar(base, p).set_index(COL_ID)["Ranking"]
        rhos.append(_rho(ref.loc[rk.index], rk))
        ints.append(len(topo_ref & set(rk[rk <= k].index)) / k)
    return {"variacao": variacao, "n_sim": n_sim, f"spearman_medio": float(np.mean(rhos)),
            "spearman_min": float(np.min(rhos)), f"top{k}_retido_medio": float(np.mean(ints)),
            f"top{k}_retido_min": float(np.min(ints))}


def cenarios(base, pesos_ahp):
    """Cenários: AHP, pesos iguais e cada critério dominante (50%)."""
    n = len(pesos_ahp)
    ref = saw.pontuar(base, pesos_ahp).set_index(COL_ID)["Ranking"]
    linhas = []
    esq = {"AHP (base)": np.asarray(pesos_ahp), "Pesos iguais": np.ones(n) / n}
    for k, c in enumerate(CRITERIOS):
        p = np.full(n, 0.5 / (n - 1)); p[k] = 0.5
        esq[f"{c['codigo']} dominante (50%)"] = p
    for nome, p in esq.items():
        rk = saw.pontuar(base, p).set_index(COL_ID)["Ranking"]
        top = set(rk[rk <= 100].index) & set(ref[ref <= 100].index)
        linhas.append({"Cenário": nome, "Spearman vs base": _rho(ref.loc[rk.index], rk), "Top-100 em comum": len(top)})
    return pd.DataFrame(linhas)


def influencia_efetiva(resultado, pesos):
    """Quanto cada critério realmente 'move' o ranking: peso nominal x desvio-padrão da contribuição."""
    linhas = []
    for k, c in enumerate(CRITERIOS):
        contrib = resultado["contrib_" + c["campo"]]
        linhas.append({"Critério": c["codigo"], "Campo": c["campo"], "Peso AHP": pesos[k],
                       "Desvio-padrão da contribuição": contrib.std(),
                       "Correlação com a pontuação": contrib.corr(resultado["Pontuacao_SAW"])})
    d = pd.DataFrame(linhas)
    d["Influência efetiva (%)"] = 100 * d["Desvio-padrão da contribuição"] / d["Desvio-padrão da contribuição"].sum()
    return d


def comparacao_exploratoria(df_original, resultado):
    """Compara ranking com Risk_Level. NÃO é validação definitiva (origem de Risk_Level desconhecida)."""
    m = resultado.merge(df_original[[COL_ID, "Risk_Level"]], on=COL_ID)
    ordem = {"Low": 1, "Medium": 2, "High": 3, "Critical": 4}
    m["nivel"] = m["Risk_Level"].map(ordem)
    media = m.groupby("Risk_Level")["Pontuacao_SAW"].agg(["mean", "count"]).reindex(ordem.keys())
    return media, _rho(m["Pontuacao_SAW"], m["nivel"])
