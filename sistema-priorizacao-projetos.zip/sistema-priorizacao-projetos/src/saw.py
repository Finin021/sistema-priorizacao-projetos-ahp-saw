"""SAW: normalização (benefício x/max; custo min/x), pontuação e ranking."""
import numpy as np
import pandas as pd
from config import CRITERIOS, COL_ID


def normalizar(base: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame({COL_ID: base[COL_ID]})
    for c in CRITERIOS:
        x = base[c["campo"]].astype(float)
        out[c["campo"]] = x / x.max() if c["sentido"] == "max" else x.min() / x
    return out


def pontuar(base: pd.DataFrame, pesos) -> pd.DataFrame:
    pesos = np.asarray(pesos, float)
    assert (pesos > 0).all() and abs(pesos.sum() - 1) < 1e-9, "Pesos inválidos"
    norm = normalizar(base)
    campos = [c["campo"] for c in CRITERIOS]
    contrib = norm[campos].values * pesos            # contribuição de cada critério
    res = base.copy()
    for k, c in enumerate(campos):
        res["norm_" + c] = norm[c]
        res["contrib_" + c] = contrib[:, k]
    res["Pontuacao_SAW"] = contrib.sum(axis=1)
    res = res.sort_values(["Pontuacao_SAW", COL_ID], ascending=[False, True]).reset_index(drop=True)
    res.insert(0, "Ranking", np.arange(1, len(res) + 1))
    return res
