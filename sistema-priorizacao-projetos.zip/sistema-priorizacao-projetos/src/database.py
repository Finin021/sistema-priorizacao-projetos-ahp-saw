"""SQLite: projetos, criterios, comparacoes_ahp, pesos, execucoes, resultados."""
import sqlite3
import datetime as dt
import numpy as np
from config import CRITERIOS, COL_ID, CAMPOS

ESQUEMA = """
CREATE TABLE IF NOT EXISTS projetos(project_id TEXT PRIMARY KEY, complexity_score REAL,
  schedule_pressure REAL, historical_risk_incidents REAL, resource_availability REAL, vendor_reliability_score REAL);
CREATE TABLE IF NOT EXISTS criterios(codigo TEXT PRIMARY KEY, campo TEXT, nome TEXT, sentido TEXT);
CREATE TABLE IF NOT EXISTS execucoes(id INTEGER PRIMARY KEY AUTOINCREMENT, data_hora TEXT, n_projetos INTEGER,
  lambda_max REAL, ci REAL, cr REAL, consistente INTEGER, observacao TEXT);
CREATE TABLE IF NOT EXISTS comparacoes_ahp(execucao_id INTEGER, criterio_a TEXT, criterio_b TEXT, valor REAL,
  FOREIGN KEY(execucao_id) REFERENCES execucoes(id));
CREATE TABLE IF NOT EXISTS pesos(execucao_id INTEGER, criterio TEXT, peso REAL,
  FOREIGN KEY(execucao_id) REFERENCES execucoes(id));
CREATE TABLE IF NOT EXISTS resultados(execucao_id INTEGER, project_id TEXT, ranking INTEGER, pontuacao REAL,
  valores_usados TEXT, FOREIGN KEY(execucao_id) REFERENCES execucoes(id));
CREATE INDEX IF NOT EXISTS ix_res ON resultados(execucao_id, ranking);
"""


def conectar(caminho):
    caminho.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(caminho)
    con.executescript(ESQUEMA)
    return con


def salvar_execucao(con, base, ahp, resultado, obs=""):
    import json
    cur = con.cursor()
    cur.executemany("INSERT OR REPLACE INTO projetos VALUES(?,?,?,?,?,?)",
                    base[[COL_ID] + CAMPOS].itertuples(index=False, name=None))
    cur.executemany("INSERT OR REPLACE INTO criterios VALUES(?,?,?,?)",
                    [(c["codigo"], c["campo"], c["nome"], c["sentido"]) for c in CRITERIOS])
    cur.execute("INSERT INTO execucoes(data_hora,n_projetos,lambda_max,ci,cr,consistente,observacao) VALUES(?,?,?,?,?,?,?)",
                (dt.datetime.now().isoformat(timespec="seconds"), len(base), ahp["lambda_max"],
                 ahp["CI"], ahp["CR"], int(ahp["consistente"]), obs))
    eid = cur.lastrowid
    cods, A = ahp["codigos"], ahp["matriz"]
    for i in range(len(cods)):
        for j in range(i + 1, len(cods)):
            cur.execute("INSERT INTO comparacoes_ahp VALUES(?,?,?,?)", (eid, cods[i], cods[j], float(A[i, j])))
    for cod, p in zip(cods, ahp["pesos"]):
        cur.execute("INSERT INTO pesos VALUES(?,?,?)", (eid, cod, float(p)))
    linhas = []
    for r in resultado.itertuples(index=False):
        usados = json.dumps({c: float(getattr(r, c)) for c in CAMPOS})
        linhas.append((eid, r.Project_ID, int(r.Ranking), float(r.Pontuacao_SAW), usados))
    cur.executemany("INSERT INTO resultados VALUES(?,?,?,?,?)", linhas)
    con.commit()
    return eid


def top(con, eid, n=10):
    return con.execute("SELECT ranking,project_id,pontuacao FROM resultados WHERE execucao_id=? ORDER BY ranking LIMIT ?",
                       (eid, n)).fetchall()
